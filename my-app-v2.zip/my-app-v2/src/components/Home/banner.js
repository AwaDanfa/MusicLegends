import React from 'react';

const Banner = () => (
    <div className="banner">
        <div className="main_cover">
            <div className="logo">YOUR MUSIC'S REFERENCE</div>
        </div>
        <span></span>
    </div>
)

export default Banner;